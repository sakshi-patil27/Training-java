package practice;
  interface Tv{
	 public void display();
	 public void sound();
	 
	  
  }
  class Led implements Tv{

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println(" display");
	}

	@Override
	public void sound() {
		// TODO Auto-generated method stub
		System.out.println("sound");
	}
	  
	  
  }
public class INterface {

	public static void main(String args[]) {
	Led l=new Led();
	l.display();
	l.sound();
     
}
}