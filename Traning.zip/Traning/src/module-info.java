/**
 * 
 */
/**
 * 
 */
module Traning {
}